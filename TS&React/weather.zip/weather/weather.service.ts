/**
 * @copyright (c)2017-present, Gago, Inc.
 * @file 气象模块 所需 api 服务，及 气象 api
 * @author wanghaodong <wanghaodong@gagogroup.com>
 */

import { transaction, toJS } from 'mobx';
import moment from 'moment';

import { HttpClient } from '../core/http-client';
import WeatherStore, { RealTimeWeatherData, AlarmData } from './weather.store';
import { AlarmTypes } from './utils/weather-type';

interface RealTimeResponse {
  realtime: RealTimeWeatherData;
}

interface GagoWeekData {
  forecastWeather: Array<{
    apcp: number; // 降雨
    date: string;
    rh: number; // 湿度
    tmax: number; // 最高温
    tmin: number; // 最低温
    tmp: number; // 平均温
    windSpeed: number; // 风速
  }>;
}

interface CNWeekData {
  forecastWeather: Array<{
    date: string;
    wep: string; // 天气类型，多云转晴等
    tmax: number;
    tmin: number;
    wind: string;
    windDirection: string;
    windSpeed: string;
  }>;
}

interface Precipitation {
  apcp: number;
}

interface Temperature {
  sumTemperature: number;
}

interface Alarm {
  addrWithPositions: Array<{
    lat: number;
    lon: number;
    id: number;
    hasAlarm: boolean;
    alarms: Array<{
      class: string;
      content: string;
      address: string;
      level: string;
      status: boolean;
      name: string;
      date: string;
    }>;
  }>;
}

interface TwoHours {
  precipitations: number[];
}

interface List {
  info: Array<{
    bounds: {
      minLat: number;
      maxLat: number;
      minLon: number;
      maxLon: number;
    };
    center: {
      lat: number;
      lon: number;
    };
    totalSize: number;
    totalArea: number;
    departmentId: number;
  }>;
}

interface Departments {
  departments: Array<{
    departmentId: number;
    departmentName: string;
  }>;
}

export class WeatherService {
  static async getList() {
    const [{ departments }, { info }] = await Promise.all([
      HttpClient.get<Departments>('/auth/departments/info'),
      HttpClient.get<List>('/lands/statistics?group=department'),
    ]);

    const lists = info.map((item) => {
      const {
        departmentId: id,
        center: { lat, lon },
        bounds: { minLat, maxLon, minLon, maxLat },
        totalSize,
        totalArea,
      } = item;

      const name = departments.filter(({ departmentId }) => departmentId === id)
        .map(({ departmentName }) => departmentName)[0];

      const center: [number, number] = [lon, lat];

      const corner = [
        [minLat, minLon],
        [minLat, maxLon],
        [maxLat, minLon],
        [maxLat, maxLon],
      ];

      return { id, name, totalSize, totalArea, center, corner };
    });

    WeatherStore.setList(lists);
  }

  static async getAlarmInfo() {
    const lists = toJS(WeatherStore.lists);
    const positions = lists.map(({ id, corner }) => {
      return corner.map(([lat, lon]) => ({ id, lat, lon }));
    }).reduce((prev, current) => prev.concat(current));
    const { addrWithPositions: result } = await HttpClient.v4Post<Alarm>('/alarm/query/all', { positions });
    const alarm: Map<number, AlarmData> = new Map();

    function parseAlarms(alarms: Alarm['addrWithPositions'][0]['alarms']): AlarmData['alarms'] {
      return alarms.map(({ level, name, content }) => ({
        level: AlarmTypes.get(level),
        type: name.slice(0, -2),
        info: content,
      }));
    }

    result.forEach(({ id, hasAlarm, alarms }) => {
      if (alarm.has(id)) {
        const data = alarm.get(id);
        const _hasAlarm = data.hasAlarm || hasAlarm;
        // 去重
        const newAlarms = parseAlarms(alarms).filter(({ type, level, info }) => {
          data.alarms.forEach((item) => {
            if (item.type === type && item.level === level && item.info === info) {
              return false;
            }
            return true;
          });
        });
        const _alarms = data.alarms.concat(newAlarms);
        alarm.set(id, {
          hasAlarm: _hasAlarm,
          alarms: _alarms,
        });
      } else {
        alarm.set(id, {
          hasAlarm,
          alarms: parseAlarms(alarms),
        });
      }
    });

    WeatherStore.setAlarmData(alarm);
  }

  static getListRealTimeWeather() {
    WeatherStore.lists.forEach(async ({ center: [lon, lat], id }) => {
      const { realtime } = await HttpClient.v4Get<RealTimeResponse>('/weather/realtime', { lat, lon });
      WeatherStore.addListItemWeather(id, {
        ...realtime,
        temperature: Number.parseInt(realtime.temperature.toFixed(), 10),
        time: moment(realtime.time).fromNow(),
      });
    });
  }

  static async getForecastWeatherData(lat: number, lon: number) {
    const features = '[wep,tmax,tmin,wind]';
    const [weekData1, weekData2, nextWeekData] = await Promise.all([
      HttpClient.v4Get<GagoWeekData>('/weather/forecastday', { lat, lon }), // 高温，低温，降水
      HttpClient.v4Dot1<CNWeekData>('/weather/coordinate/cnweatherforecast7', { lat, lon, features }), // 天气类型
      HttpClient.v4Dot1<CNWeekData>('/weather/coordinate/cnweatherforecast8', { lat, lon, features }), // 天气类型
    ]);

    const todayData = {
      type: weekData2.forecastWeather[0].wep, // 晴天
      precipitation: weekData1.forecastWeather[0].apcp, // 降水量
      highestTemperature: weekData2.forecastWeather[0].tmax,
      lowestTemperature: weekData2.forecastWeather[0].tmin,
    };
    const fourteenDaysData = [...weekData2.forecastWeather, ...nextWeekData.forecastWeather]
      .map(({ date, wep, tmax, tmin, windDirection, windSpeed }) => ({
        date,
        windDirection,
        windPower: windSpeed,
        type: wep,
        lowestTemperature: tmin,
        highestTemperature: tmax,
      }));

    transaction(() => {
      WeatherStore.setTodayWeatherData(todayData);
      WeatherStore.setFourteenDaysWeatherData(fourteenDaysData);
    });
  }

  static async getLastYearData(lat: number, lon: number) {
    const { date } = WeatherStore.analysisData;
    const from_date = date.clone().subtract(1, 'year').format('YYYY-MM-DD'); // tslint:disable-line
    const to_date = moment().subtract(1, 'year').format('YYYY-MM-DD'); // tslint:disable-line
    const precipitation = HttpClient.v4Get<Precipitation>('/weather/analysis/history_apcp', { lat, lon, from_date, to_date });
    const temperature = HttpClient.v4Get<Temperature>('/weather/analysis/history_sum_temperature', { lat, lon, from_date, to_date });
    return Promise.all([precipitation, temperature]).then(([data1, data2]) => [data1.apcp, data2.sumTemperature]);
  }

  static async getThisYearData(lat: number, lon: number) {
    const { date } = WeatherStore.analysisData;
    const from_date = date.clone().format('YYYY-MM-DD'); // tslint:disable-line
    const to_date = moment().format('YYYY-MM-DD'); // tslint:disable-line
    const precipitation = HttpClient.v4Get<Precipitation>('/weather/analysis/history_apcp', { lat, lon, from_date, to_date });
    const temperature = HttpClient.v4Get<Temperature>('/weather/analysis/history_sum_temperature', { lat, lon, from_date, to_date });
    return Promise.all([precipitation, temperature]).then(([data1, data2]) => [data1.apcp, data2.sumTemperature]);
  }

  static async getAnalysisData(lat: number, lon: number) {
    const [data1, data2] = await Promise.all([WeatherService.getLastYearData(lat, lon), WeatherService.getThisYearData(lat, lon)]);

    const [lastYearPrecipitation, lastYearTemperature] = data1;
    const [thisYearPrecipitation, thisYearTemperature] = data2;
    const compare1 = (thisYearPrecipitation - lastYearPrecipitation) / lastYearPrecipitation * 100 || 0;
    const compare2 = (thisYearTemperature - lastYearTemperature) / lastYearTemperature * 100;

    WeatherStore.setAnalysisData(thisYearPrecipitation, thisYearTemperature, compare1, compare2);
  }

  static async getTwoHoursPrecipitation(lat: number, lon: number) {
    const { precipitations } = await HttpClient.get<TwoHours>('/weather/precipitations', { lat, lon, interval: 15 });
    WeatherStore.setPrecipitations(precipitations);
  }
}
