import React, { Component } from 'react';
import { observer } from 'mobx-react';

import { classnames } from '../../../utils';
import {
  Mapbox,
  Control,
  Marker,
  BaseLayer,
  BoundaryLine,
  Annotation,
} from '../../shared/mapbox';
import { GagoIcon } from '../../shared';
import { LayerControl } from '../../shared/label-control/label-control';
import LabelStore from '../../shared/label-control/label-control.store';
import WeatherStore from '../weather.store';
import { WeatherTypes } from '../utils/weather-type';
import { CommonLand } from '../../shared/land/land';

import styles from './map.module.scss';
import redWarningIcon from '../images/red-warning.svg';

@observer
export class MapComponent extends Component {

  private renderMarkers() {
    const { lists, currentIndex } = WeatherStore;
    return lists.map(({ id, name, center }, index) => {
      const weatherData = WeatherStore.getRealTimeWeatherData(id);
      const hasAlarm = WeatherStore.getHasAlarm(id);
      const classes = classnames(styles.marker, {
        [styles.active]: index === currentIndex,
      });
      return (
        <Marker key={id} coordinates={center.slice()}>
          <div className={classes}>
            <div>
              <span>{name}</span>
              {hasAlarm && <img src={redWarningIcon} alt="预警警告" />}
            </div>
            <GagoIcon type={WeatherTypes.get(weatherData.weatherDescription)} />
            <span>{weatherData.temperature}℃</span>
          </div>
        </Marker>
      );
    });
  }

  render() {
    const { currentItem: { center } } = WeatherStore;
    const _center = center.slice().length === 2 ? center.slice() : [120.7, 37.16];
    const jumpTo = center.slice().length === 2 ? { options: { center: center.slice() } } : undefined;

    return (
      <Mapbox options={{ center: _center, zoom: 14 }} jumpTo={jumpTo} >
        <BaseLayer type="google-satellite" visibility={LabelStore.baseLayers.get('google-satellite')} />
        <BaseLayer type="google-normal" visibility={LabelStore.baseLayers.get('google-normal')} />
        <BoundaryLine />
        <Annotation />
        <CommonLand />
        <Control type="scale" position="bottom-right" />
        <Control type="navigation" position="bottom-right" options={{ showCompass: false }} />
        <LayerControl />
        {this.renderMarkers()}
      </Mapbox>
    );
  }
}
