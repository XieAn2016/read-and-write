import { observable, action, computed } from 'mobx';
import moment from 'moment';
import 'moment/locale/zh-cn';

moment.locale('zh-cn');

export interface RealTimeWeatherData {
  temperature: number;
  weatherDescription: string;
  humidity: number;
  windpower: number;
  time: string;
}

export interface TodayWeatherData {
  /** 晴天 | 阴天 */
  type: string; // 晴天
  /** 降水量 */
  precipitation: number;
  /** 最高温 */
  highestTemperature: number;
  /** 最低温 */
  lowestTemperature: number;
}

export interface ForecastWeatherData {
  /** 日期 */
  date: string;
  /** 晴天 | 阴天 */
  type: string; // 晴天
  /** 最高温 */
  highestTemperature: number;
  /** 最低温 */
  lowestTemperature: number;
  /** 风向 */
  windDirection: string;
  /** 风力 */
  windPower: string;
}

interface AnalysisData {
  date: moment.Moment;
  compareToPrecipitation: number;
  precipitation: number;
  compareToTemperature: number;
  temperature: number;
}

export interface AlarmData {
  hasAlarm: boolean;
  alarms: Array<{
    level: string;
    type: string;
    info: string;
  }>;
}

export interface ListItem {
  id: number;
  name: string;
  center: number[];
  corner: number[][];
  totalSize: number;
  totalArea: number;
}

const DEFAULT_REALTIME_WEATHER_DATA: RealTimeWeatherData = {
  weatherDescription: '',
  temperature: null,
  windpower: null,
  humidity: null,
  time: null,
};

class WeatherStore {
  @observable lists: ListItem[] = [];
  @observable listRealTimeWeather: Map<number, RealTimeWeatherData> = new Map();
  @observable currentIndex: number = null;

  @observable todayWeatherData: TodayWeatherData = {
    type: '',
    precipitation: null,
    highestTemperature: null,
    lowestTemperature: null,
  };

  @observable fourteenDaysWeatherData: ForecastWeatherData[] = [];

  @observable analysisData: AnalysisData = {
    date: moment().startOf('year'),
    compareToPrecipitation: null,
    precipitation: null,
    compareToTemperature: null,
    temperature: null,
  };

  @observable alarmData: Map<number, AlarmData> = new Map();

  @observable precipitations: number[] = [];

  @computed get canRender() {
    return this.lists.length > 0 && this.listRealTimeWeather.size > 0;
  }

  @computed get currentItem(): ListItem {
    if (this.canRender) {
      return this.lists[this.currentIndex];
    }

    return {
      id: null,
      name: '',
      center: [],
      corner: [],
      totalArea: null,
      totalSize: null,
    };
  }

  @computed get currentRealTimeWeather(): RealTimeWeatherData {
    let data;
    if (this.canRender) {
      const { id } = this.lists[this.currentIndex];
      data = this.listRealTimeWeather.get(id);
    }

    return data === undefined ? DEFAULT_REALTIME_WEATHER_DATA : data;
  }

  @computed get currentAlarm(): AlarmData {
    if (this.canRender && this.alarmData.size > 0) {
      const { id } = this.lists[this.currentIndex];
      return this.alarmData.get(id);
    }

    return { hasAlarm: false, alarms: [] };
  }

  getRealTimeWeatherData(id: number): RealTimeWeatherData {
    const data = this.listRealTimeWeather.get(id);
    return data === undefined ? DEFAULT_REALTIME_WEATHER_DATA : data;
  }

  getHasAlarm(id: number): boolean {
    const data = this.alarmData.get(id);
    return data === undefined ? false : data.hasAlarm;
  }

  @action
  setCurrentIndex(index: number) {
    this.currentIndex = index;
  }

  @action
  setList(data: ListItem[]) {
    this.lists.push(...data);
  }

  @action
  clearList() {
    // @ts-ignore observable array, this method provide by mobx
    this.lists.clear();
    this.listRealTimeWeather.clear();
  }

  @action
  addListItemWeather(id: number, data: RealTimeWeatherData) {
    this.listRealTimeWeather.set(id, data);
  }

  @action
  setTodayWeatherData({ type, precipitation, highestTemperature, lowestTemperature }: TodayWeatherData) {
    this.todayWeatherData.type = type;
    this.todayWeatherData.precipitation = precipitation;
    this.todayWeatherData.lowestTemperature = lowestTemperature;
    this.todayWeatherData.highestTemperature = highestTemperature;
  }

  @action
  setFourteenDaysWeatherData(data: ForecastWeatherData[]) {
    this.fourteenDaysWeatherData.push(...data);
  }

  @action
  clearFourteenDaysWeatherData() {
    // @ts-ignore observable array, this method provide by mobx
    this.fourteenDaysWeatherData.clear();
  }

  @action
  setAnalysisData(precipitation: number, temperature: number, comparePrecipitation: number, compareToTemperature: number) {
    this.analysisData.precipitation = Number.parseInt((precipitation.toFixed()), 10);
    this.analysisData.temperature = Number.parseInt(temperature.toFixed(), 10);
    this.analysisData.compareToPrecipitation = Number.parseInt(comparePrecipitation.toFixed(), 10);
    this.analysisData.compareToTemperature = Number.parseInt(compareToTemperature.toFixed(), 10);
  }

  @action.bound
  setAnalysisDataDate(date: moment.Moment) {
    this.analysisData.date = date;
  }

  @action
  setAlarmData(data: Map<number, AlarmData>) {
    for (const [key, value] of data) {
      this.alarmData.set(key, value);
    }
  }

  @action
  clearAlarmData() {
    this.alarmData.clear();
  }

  @action
  setPrecipitations(data: number[]) {
    this.precipitations.push(...data);
  }

  @action
  clearPrecipitations() {
    // @ts-ignore observable array, this method provide by mobx
    this.precipitations.clear();
  }
}

export default new WeatherStore();
