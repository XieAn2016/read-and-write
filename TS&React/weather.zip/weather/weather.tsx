import React, { PureComponent } from 'react';
import { Switch, Route, Redirect, RouteComponentProps } from 'react-router-dom';
import { reaction } from 'mobx';

import { SiderComponent } from './sider/sider';
import { MapComponent } from './map/map';
import { ChartComponent } from './chart/chart';
import { WeatherService } from './weather.service';
import WeatherStore from './weather.store';

reaction(() => ({
  length: WeatherStore.lists.length,
}), ({ length }) => {
  if (length <= 0) {
    WeatherStore.setCurrentIndex(null);
    WeatherStore.clearAlarmData();
    WeatherStore.clearFourteenDaysWeatherData();
    WeatherStore.clearPrecipitations();
    return;
  }
  WeatherStore.setCurrentIndex(0);
  WeatherService.getListRealTimeWeather();
});

export class WeatherComponent extends PureComponent<RouteComponentProps<any>> {

  async componentDidMount() {
    await WeatherService.getList();
    WeatherService.getAlarmInfo();
  }

  render() {
    const { match } = this.props;
    return (
      <>
        <SiderComponent />
        <Switch>
          <Route path={`${match.path}/map`} component={MapComponent} />
          <Route path={`${match.path}/chart`} component={ChartComponent} />
          <Redirect to={`${match.path}/chart`} />
        </Switch>
      </>
    );
  }
}
