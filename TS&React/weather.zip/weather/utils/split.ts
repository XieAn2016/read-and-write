/** 天气中带转时，只取白天数据 */
export function split(text: string) {
  return text.split('转')[0];
}
