import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { ResponsiveContainer, ComposedChart, XAxis, YAxis, Line, Area, CartesianGrid } from 'recharts';

import { Panel } from '../panel/panel';
import WeatherStore from '../../weather.store';

import commonStyles from '../chart.module.scss';

@observer
export class PrecipitationComponent extends Component {

  private tickFormatter(value: number) {
    if (value === 0.05) {
      return '小雨';
    }
    if (value === 0.9) {
      return '中雨';
    }
    if (value === 2.87) {
      return '大雨';
    }
    return value;
  }

  render() {
    const data = WeatherStore.precipitations.slice().map((item, index) => ({
      name: `${index * 15}分钟`, value: item,
    }));
    return (
      <Panel title="2小时降雨预报" className={commonStyles.panel}>
        <ResponsiveContainer minHeight={150}>
          <ComposedChart data={data} margin={{ right: 50 }}>
            <XAxis dataKey="name" padding={{ left: 8, right: 8 }} />
            <YAxis
              allowDataOverflow
              ticks={[0.05, 0.9, 2.87]}
              tickFormatter={this.tickFormatter}
              interval={0}
              domain={[0, 3.2]}
              padding={{ top: 0, bottom: 8 }}
            />
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <Line type="monotone" dataKey="value" stroke="#01bcd4" strokeOpacity={1} dot={false} isAnimationActive={false} />
            <Area type="monotone" dataKey="value" fill="rgba(1, 188, 212, 0.2)" fillOpacity={1} />
          </ComposedChart>
        </ResponsiveContainer>
      </Panel>
    );
  }
}
