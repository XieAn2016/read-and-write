import React, { SFC } from 'react';

import { classnames } from '../../../../utils';

import styles from './panel.module.scss';

interface Props {
  title?: string;
  className?: string;
  style?: React.CSSProperties;
}

export const Panel: SFC<Props> = ({ title, className, style, children }) => (
  <div className={classnames(styles.container, className)} style={style}>
    {title === undefined ? null : <h3 className={styles.title}>{title}</h3>}
    <div className={styles.content}>{children}</div>
  </div>
);
