import React, { Component, SFC } from 'react';
import { observer } from 'mobx-react';
import moment from 'moment';

import { GagoIcon } from '../../../shared';
import { Panel } from '../panel/panel';
import WeatherStore, { ForecastWeatherData } from '../../weather.store';
import { WeatherTypes } from '../../utils/weather-type';
import { split } from '../../utils/split';

import commonStyles from '../chart.module.scss';
import styles from './forecast.module.scss';

const Card: SFC<ForecastWeatherData> = ({ date, type, lowestTemperature, highestTemperature, windDirection, windPower }) => (
  <div className={styles.card}>
    <span>{moment(date).format('ddd')}</span>
    <span>{moment(date).format('MMM Do').replace(/\s/g, '')}</span>
    <GagoIcon className={styles.icon} type={WeatherTypes.get(split(type))} />
    <span>{type}</span>
    <span>{lowestTemperature}℃ ~ {highestTemperature}℃</span>
    <span>{split(windDirection)} {split(windPower)}</span>
  </div>
);

@observer
export class ForecastComponent extends Component {
  render() {
    return (
      <Panel title="14日天气预报" className={commonStyles.panel}>
        {WeatherStore.fourteenDaysWeatherData.map((item) => <Card key={item.date} {...item} />)}
      </Panel>
    );
  }
}
