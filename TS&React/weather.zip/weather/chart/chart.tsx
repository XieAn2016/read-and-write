import React from 'react';

import { TodayComponent } from './today/today';
import { AnalysisComponent } from './analysis/analysis';
import { PrecipitationComponent } from './precipitation/precipitation';
import { ForecastComponent } from './forecast/forecast';

import styles from './chart.module.scss';

export const ChartComponent = () => (
  <div className={styles.container}>
    <TodayComponent />
    <AnalysisComponent />
    <PrecipitationComponent />
    <ForecastComponent />
  </div>
);
