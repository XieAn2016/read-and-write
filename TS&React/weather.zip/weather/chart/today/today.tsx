import React, { Component, SFC } from 'react';
import { observer } from 'mobx-react';
import { Tooltip } from 'antd';

import { classnames } from '../../../../utils';
import { GagoIcon } from '../../../shared';
import { Panel } from '../panel/panel';
import WeatherStore from '../../weather.store';
import { WeatherTypes } from '../../utils/weather-type';
import { split } from '../../utils/split';

import styles from './today.module.scss';

interface CardProps {
  title: string;
}

interface AlarmProps {
  type: string;
}

const Card: SFC<CardProps> = ({ title, children }) => (
  <div className={styles.card}>
    <div>{title}</div>
    <div className={styles.content}>{children}</div>
  </div>
);

const Alarm: SFC<AlarmProps> = ({ type, children }) => {
  const classes = classnames(styles.warning, {
    [styles.red]: type === 'red',
    [styles.orange]: type === 'orange',
    [styles.yellow]: type === 'yellow',
    [styles.blue]: type === 'blue',
  });
  return <span className={classes}>{children}</span>;
};

@observer
export class TodayComponent extends Component {

  private renderAlarmTag() {
    const { hasAlarm, alarms } = WeatherStore.currentAlarm;

    if (!hasAlarm) {
      return (<span>今日无预警</span>);
    }

    return alarms.map(({ level, type: alarmType }, index) => (
      <Alarm key={index} type={level}>{alarmType}</Alarm>
    ));
  }

  private renderAlarmInfo() {
    const { hasAlarm, alarms } = WeatherStore.currentAlarm;

    if (!hasAlarm) {
      return (<span>- -</span>);
    }

    return alarms.map(({ info }, index) => (
      <Tooltip key={index} placement="leftTop" title={info}>
        <div>{info}</div>
      </Tooltip>
    ));
  }

  render() {
    if (!WeatherStore.canRender) {
      return (
        <Panel title="今日天气">
          <Card title="" />
          <Card title="灾害预警" />
          <Card title="降水量" />
          <Card title="农事提醒" />
        </Panel>
      );
    }

    const { type, precipitation, highestTemperature, lowestTemperature } = WeatherStore.todayWeatherData;

    return (
      <Panel title="今日天气">
        <Card title={type}>
          <GagoIcon className={styles.icon} type={WeatherTypes.get(split(type))} />
          <span className={styles.value}>
            {highestTemperature}/{lowestTemperature}
            <span className={styles.unit}> ℃</span>
          </span>
        </Card>
        <Card title="灾害预警">
          {this.renderAlarmTag()}
        </Card>
        <Card title="降水量">
          <span className={styles.value}>
            {precipitation} <span className={styles.unit}>mm</span>
          </span>
        </Card>
        <Card title="农事提醒">
          {this.renderAlarmInfo()}
        </Card>
      </Panel>
    );
  }
}
