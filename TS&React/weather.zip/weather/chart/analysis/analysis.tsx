import React, { Component, SFC } from 'react';
import { reaction } from 'mobx';
import { observer } from 'mobx-react';
import moment from 'moment';
import { Icon, DatePicker } from 'antd';
import locale from 'antd/lib/date-picker/locale/zh_CN';

import { classnames } from '../../../../utils';
import { Panel } from '../panel/panel';
import WeatherStore from '../../weather.store';
import { WeatherService } from '../../weather.service';

import styles from './analysis.module.scss';

interface Props {
  title: string;
  date: moment.Moment;
  unit: string;
  value: number;
  compare: number;
}

// 日期变化时
reaction(() => ({
  date: WeatherStore.analysisData.date,
}), () => {
  const { center: [lon, lat] } = WeatherStore.currentItem;
  WeatherService.getAnalysisData(lat, lon);
});

const Card: SFC<Props> = ({ title, date, unit, value, compare }) => (
  <div className={styles.card}>
    <h3>
      <span>{title}</span>&nbsp;
      <Icon className={styles.icon} type="question-circle-o" />
    </h3>
    <div className={styles.content}>
      <div className={styles.box}>
        <span className={classnames(styles.item, styles.big)}>{value}<span className={styles.small}>&nbsp;{unit}</span></span>
        <span className={styles.item}>自{date.format('MMM Do')}计算</span>
      </div>
      <div className={styles.box}>
        <span className={classnames(styles.item, styles.small)}>{compare > 0 ? `+${compare}` : compare}%</span>
        <span className={styles.item}>较去年同期</span>
      </div>
      <div className={styles.box}><Icon className={styles.icon} type={compare > 0 ? 'arrow-up' : 'arrow-down'} /></div>
    </div>
  </div>
);

@observer
export class AnalysisComponent extends Component {

  private getDisableDateRange(current: moment.Moment) {
    return current && !current.isBetween(moment().startOf('year'), moment());
  }

  private datePickerHandler(date: moment.Moment | null) {
    if (date === null) {
      return;
    }
    WeatherStore.setAnalysisDataDate(date);
  }

  render() {
    const { date, precipitation, compareToPrecipitation, temperature, compareToTemperature } = WeatherStore.analysisData;
    return (
      <Panel>
        <DatePicker
          className={styles.coverAntDatePicker}
          size="small"
          locale={locale}
          placeholder="选择播种日期"
          disabledDate={this.getDisableDateRange}
          onChange={this.datePickerHandler}
          allowClear={false}
        />
        <Card title="累积降水量分析" unit="mm" date={date} value={precipitation} compare={compareToPrecipitation} />
        <Card title="有效积温分析" unit="d·℃" date={date} value={temperature} compare={compareToTemperature} />
      </Panel>
    );
  }
}
