import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Link, withRouter, RouteComponentProps } from 'react-router-dom';
import { Icon } from 'antd';
import moment from 'moment';

import WeatherStore from '../../weather.store';
import { GagoIcon } from '../../../shared';
import { classnames } from '../../../../utils';
import { WeatherTypes, WeatherBackgroundImages } from '../../utils/weather-type';
import { split } from '../../utils/split';
import { Lunar } from '../../../../plugins/lunar';

import styles from './card.module.scss';
import humidityIcon from './icons/humidity.svg';
import mapIcon from './icons/map.svg';
import chartIcon from './icons/chart.svg';

// @ts-ignore 查看 withRouter 的注释
@withRouter
@observer
export class CardComponent extends Component<Partial<RouteComponentProps<any>>> { // 使用 partial 避免在 sider 中的警告

  componentWillUnmount() {
    WeatherStore.clearList();
  }

  private renderLink() {
    const { match, location: { pathname } } = this.props;
    const link = pathname.split('/')[2];
    const iconType = link === 'chart' ? mapIcon : chartIcon;
    const iconText = link === 'chart' ? '地图展示' : '图表展示';
    const _link = link === 'chart' ? 'map' : 'chart';

    return (
      <Link className={styles.link} to={`${match.url}/${_link}`}>
        <img src={iconType} alt={_link} />
        <span>{iconText}</span>
        <Icon type="right" className={styles.arrowIcon} />
      </Link>
    );
  }

  render() {
    const now = moment().format('MM/DD dddd');
    const {
      currentItem: data,
      currentRealTimeWeather: weatherData,
    } = WeatherStore;
    const type = WeatherBackgroundImages.get(split(weatherData.weatherDescription));
    const cardClasses = classnames(styles.card, {
      [styles.rain]: type === 'rain',
      [styles.snow]: type === 'snow',
      [styles.sun]: type === 'sun',
      [styles.cloud]: type === 'cloud',
      [styles.sand]: type === 'sand',
    });

    return (
      <>
        <div className={cardClasses}>
          <div className={styles.date}>
            <span>{now}</span>
            <span>{Lunar(new Date())}</span>
            <GagoIcon className={styles.icon} type={WeatherTypes.get(weatherData.weatherDescription)} />
          </div>
          <div className={styles.address}>
            <Icon type="environment-o" />
            &nbsp;{data === undefined ? '' : data.name}
          </div>
          <div className={styles.temperature}>
            <span>{weatherData.temperature}</span><span className={styles.unit}>℃</span>
          </div>
          <div className={styles.info}>
            <span>{weatherData.weatherDescription}/风力 {weatherData.windpower}级</span>
            <img src={humidityIcon} alt="humidity"/>
            <span>{weatherData.humidity}%</span>
            <span>{weatherData.time}发布</span>
          </div>
        </div>
        <div className={styles.bar}>
          <h1 className={styles.title}>我的农场</h1>
          {this.renderLink()}
        </div>
      </>
    );
  }
}
