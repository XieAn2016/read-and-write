import React, { Component, SFC } from 'react';
import { reaction } from 'mobx';
import { observer } from 'mobx-react';
import { Icon } from 'antd';

import { classnames } from '../../../../utils';
import { ShadowScrollbars } from '../../../shared';
import WeatherStore, { ListItem, RealTimeWeatherData } from '../../weather.store';
import { WeatherService } from '../../weather.service';

import styles from './list.module.scss';
import redWarningIcon from '../../images/red-warning.svg';

interface Props {
  data: Omit<ListItem, 'id' | 'corner'>;
  weather: Omit<RealTimeWeatherData, 'weatherDescription' | 'time'>;
  hasAlarm: boolean;
  isActive: boolean;
  onClick(): void;
}

// 切换列表项时
reaction(() => ({
  currentIndex: WeatherStore.currentIndex,
}), ({ currentIndex }) => {
  if (currentIndex === null) {
    return;
  }
  WeatherStore.clearFourteenDaysWeatherData();
  WeatherStore.clearPrecipitations();
  const { center: [lon, lat] } = WeatherStore.lists[currentIndex];
  WeatherService.getForecastWeatherData(lat, lon);
  WeatherService.getAnalysisData(lat, lon);
  WeatherService.getTwoHoursPrecipitation(lat, lon);
});

const Card: SFC<Props> = ({ data, weather, hasAlarm, isActive, onClick }) => {
  const classes = classnames(styles.card, { [styles.active]: isActive });
  return (
    <div className={classes} onClick={onClick} >
      <div className={styles.title}>
        <Icon type="home" />
        <div>{data.name}</div>
        {hasAlarm && <img src={redWarningIcon} alt="预警警告" />}
        <span><i>{data.totalSize}</i>块</span>
        <span><i>{data.totalArea.toFixed(2)}</i>亩</span>
      </div>
      <div className={styles.content}>
        <div className={styles.item}>
          <span>{weather.temperature}℃</span>
          <span>气温</span>
        </div>
        <div className={styles.item}>
          <span>--</span>
          <span>降水</span>
        </div>
        <div className={styles.item}>
          <span>{weather.windpower}级</span>
          <span>风力</span>
        </div>
        <div className={styles.item}>
          <span>{weather.humidity}%</span>
          <span>湿度</span>
        </div>
      </div>
    </div>
  );
};

@observer
export class ListComponent extends Component {

  private renderCards() {
    const { lists, currentIndex } = WeatherStore;
    return lists.map(({ id, corner, ...data }, index) => {
      const { weatherDescription, time, ...weather } = WeatherStore.getRealTimeWeatherData(id);
      const hasAlarm = WeatherStore.getHasAlarm(id);
      return (
        <Card
          key={id}
          data={data}
          weather={weather}
          hasAlarm={hasAlarm}
          isActive={index === currentIndex}
          onClick={() => WeatherStore.setCurrentIndex(index)}
        />
      );
    });
  }

  render() {
    return (
      <div className={styles.container}>
        <ShadowScrollbars style={{ height: 'calc(100% - 24px)' }}>
          {this.renderCards()}
        </ShadowScrollbars>
      </div>
    );
  }
}
