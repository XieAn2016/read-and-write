import React, { SFC } from 'react';

import { CardComponent } from './card/card';
import { ListComponent } from './list/list';

import styles from './sider.module.scss';

export const SiderComponent: SFC = () => (
  <div className={styles.container}>
    <CardComponent />
    <ListComponent />
  </div>
);
