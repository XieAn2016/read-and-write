// Copyright 2018 sunhaonan (sunhaonan@gagogroup.com). All rights reserved.
// Use of this source code is governed a license that can be found in the LICENSE file.

/**
 * @component FarmInquireSideBarComp
 * @description 农事查询侧边栏组件
 * @time 2018/08/09
 * @author SHN
 */
import * as React from 'react';
import { Button, DatePicker, Select, Input, Pagination } from 'antd';
import { observer } from 'mobx-react';
import { CardComponent } from './card/card';
import { ShadowScrollbars } from '../../shared';
import ListStore from './list.store';
import FarmStore from '../farm.store';
import { ListService } from './list.service';
import DepartmentStore from '../../shared/departments/department.store';
import { DepartmentService } from '../../shared/departments/department.service';

import styles from './sider-list.module.scss';

const Option = Select.Option;
const Search = Input.Search;

interface States {
  sideBarContentHeight: string; // 侧边栏高度
  displayBtnClass: string; // 开关按钮样式
  wrapperHeight: string; // wrapper高度
}

interface Props {
  curCardChange(value: any): void;
  highlightCardID: number; // 高亮卡片
}

@observer
export class SiderListComponent extends React.Component<Props, States> {
  public sideBarContentHeight = 'calc(100% - 90px)';
  public displayBtnClass = styles.newDisplayBtn;
  public wrapperHeight = '99%';
  constructor(props?: any, context?: any) {
    super(props, context);
    this.state = {
      sideBarContentHeight: this.sideBarContentHeight,
      displayBtnClass: this.displayBtnClass,
      wrapperHeight: this.wrapperHeight,
    };
  }

  componentWillMount() {
    DepartmentService.getDepartment().then((result: any) => {
      DepartmentStore.setDepartments(result.data);
      DepartmentStore.curCooperationChange(JSON.stringify(result.data[0]));
      // 请求列表数据
      ListService.getInquireAllListData(result.data[0].departmentId);
    });
  }

  componentWillUnmount() {
    ListStore.clearData();
  }

  render() {
    return (
      <div>
        <div className={styles.farminquireSidebarWrapper} style={{ width: '350px', height: `${this.state.wrapperHeight}` }}>
          <div className={styles.titleBox}>
            <Select
              size="small"
              style={{ marginRight: '10px', maxWidth: '78px' }}
              onChange={this.changeCurDepartment}
              value={DepartmentStore.curCooperation.departmentName}
              placeholder="合作社"
            >
              {
                DepartmentStore.departments.length > 0 && DepartmentStore.departments.map((item: any, index: number) => {
                  return(
                  <Option key={'coop' + index} value={JSON.stringify(item)}>
                    {item.departmentName}
                  </Option>);
                })
              }
            </Select>
            <DatePicker
             className={styles.farminquireSidebarDatePicker}
             onChange={ListStore.setStartTimeChange}
             placeholder="起始日期"
             format={'YY/MM/DD'}
            />
            <span className={styles.strikethrough}> - </span>
            <DatePicker
              className={styles.farminquireSidebarDatePicker}
              onChange={ListStore.setEndTimeChange}
              placeholder="结束日期"
              format={'YY/MM/DD'}
            />
            <Button onClick={ListService.clickTimeFind} className={styles.searchBtn} type="primary">
              查询
            </Button>
          </div>
          <div className={styles.inquireContentBox} style={{ height: `${this.state.sideBarContentHeight}` }}>
              <div className={`${styles.inquireSearchBox} ${styles.clearfloat}`}>
                <div className={styles.fl}>
                  <i className={styles.seprate}/>
                  <span className={styles.inquireRecord}>农事记录</span>
                  <span className={styles.inquireRecordNum}>{ListStore.itemCount}</span>
                </div>
                <div className={styles.fr}>
                  <Search
                    placeholder="请输入"
                    onSearch={value => ListService.clickSearch(value)}
                    style={{ width: 110, marginRight: '10px' }}
                    size="small"
                  />
                  {/* <i className="icon_filter" /> */}
                  <i className={styles.iconSort} onClick={ListStore.listDataSortOfTime} />
                  {/* <Button type="primary" size="small" ghost>导出</Button> */}
                </div>
              </div>
              <ShadowScrollbars style={{ height: 'calc(100% - 68px)', paddingLeft: '10px' }}>
              {
                ListStore.listData.length > 0 && ListStore.listData.map((item: any) => {
                  return(
                  <CardComponent
                    cardData={item}
                    key={`inquireCard${item.id}`}
                    checked={FarmStore.highlightCardID === item.id ? true : false}
                  />);
                })
              }
              </ShadowScrollbars>
              <div className={styles.landManagePagination}>
                <Pagination
                  simple
                  defaultCurrent={1}
                  defaultPageSize={12}
                  current={ListStore.currentPage}
                  total={ListStore.itemCount}
                  onChange={this.changePage}
                  hideOnSinglePage
                />
              </div>
          </div>
        <div className={this.state.displayBtnClass} onClick={this.handleShowHidden} >
          <div className={styles.newDisplayBtnI}>
            <hr/>
            <hr/>
            <hr/>
          </div>
        </div>
        </div>
      </div>
    );
  }

  // 点击显示隐藏侧边栏
  private handleShowHidden = () => {
    this.setState({
      sideBarContentHeight: this.state.sideBarContentHeight !== '0px' ? '0px' : this.sideBarContentHeight, // 显隐sider
      displayBtnClass: this.state.displayBtnClass.split(' ').length > 1
      ? styles.newDisplayBtn :
      `${styles.newDisplayBtn} ${styles.newDisplayBtnRadius}`, // 更改缩放按钮样式
      wrapperHeight: this.state.wrapperHeight !== '85px' ? '85px' : this.wrapperHeight,
    });
  }
  // 改变分页
  private changePage = (page: number) => {
    ListStore.changePage(page);
    ListService.getInquireAllListData(DepartmentStore.curCooperation.departmentId, ListStore.searchData);
  }
  // 改变当前合作社
  private changeCurDepartment = (e: any) => {
    ListService.getInquireAllListData(JSON.parse(e).departmentId)
      .then(() => {
        ListStore.changeSearch('');
        ListStore.changePage(1);
        ListStore.setStartTimeChange(null);
        ListStore.setEndTimeChange(null);
      });
    DepartmentStore.curCooperationChange(e);
  }
}
