/*
Copyright 2018 sunhaonan (sunhaonan@gagogroup.com). All rights reserved.
Use of this source code is governed a license that can be found in the LICENSE file.
*/

/**
 * @component FarmInquireCard
 * @description 农事查询卡片件
 * @time 2018/08/10
 * @author SHN
 */
import * as React from 'react';
import { observer } from 'mobx-react';
import moment from 'moment';
import { FarmService } from '../../farm.service';
import { TransWeek } from '../../../../utils/transdate';

import styles from './card.module.scss';

interface CardData {
  updatedAt: any;
  userName: string;
  id: number;
  recordLatitude: string;
  recordLongitude: string;
  recordText: string;
  recordPictureUrls: any[];
}

interface Props {
  checked: boolean;
  cardData: CardData;
}

@observer
export class CardComponent extends React.Component<Props> {
  constructor(props?: any, context?: any) {
    super(props, context);
  }

  render() {
    const { updatedAt, userName, id, recordLatitude, recordLongitude, recordText, recordPictureUrls } = this.props.cardData;
    return (
      <div className={`${styles.inquireCardCommon} ${styles.clearfloat}`}>
        <div
          className={`${styles.inquireCardCommonContent}
          ${styles.clearfloat} ${this.props.checked
              ? styles.inquireCardCommonChecked : ''}`}
        >
          <div className={`${styles.inquireCardContentBox} ${styles.clearfloat}`}>
            <div className={`${styles.inquireCardContentBoxHeader} ${styles.fl}`}>
              <span className={styles.inquireCardCommonDate}>{moment(updatedAt).format('YYYY年MM月DD日')}</span>
              <span className={styles.inquireCardCommonWeek}>{TransWeek[moment(updatedAt).format('e') as any as number]}</span>
              <span className={styles.inquireCardCommonTitle}>{moment(updatedAt).format('HH:mm')}</span>
              <span className={styles.inquireCardCommonTitle}>{userName}</span>
            </div>
            <div
              className={styles.inquireCardContent}
              onClick={() => FarmService.getNoteDetail(id, Number(recordLongitude), Number(recordLatitude))}
            >
              {recordText}
            </div>
          </div>
          <div className={styles.inquireCardBox}>
            {
              recordPictureUrls[0] ?
                <img
                  src={recordPictureUrls[0]}
                  alt="田地图片"
                  className={styles.inquireCardBoxImg}
                /> : <div className={styles.inquireCardBoxImgBox}>
                  <div className={styles.inquireCardBoxImgBoxMain}>
                    <div className={styles.inquireCardBoxImgNone} />
                    <p className={styles.inquireCardBoxImgNoneTitle}>无图片</p>
                  </div>
                </div>
            }
          </div>
        </div>
      </div>
    );
  }
}
