import { computed, observable, action } from 'mobx';
import moment from 'moment';

export class FarmListStore {
  @observable startTime = ''; // 起始时间
  @observable endTime = ''; // 结束时间
  @observable curOperator = ''; // 农机手
  @observable.ref listData: Array<{[x: string]: any}> = []; // 列表数据
  @observable curCooperation = ''; // 合作社
  @observable searchData = ''; // 搜索内容
  @observable currentPage = 1; // 当前页数
  @observable itemCount = 0; // 总条数

  @computed get listDataLength() {
    return this.listData.length;
  }

  // 列表数据变化
  @action
  setListData(data: Array<{[x: string]: any}>) {
    this.listData = data;
  }
  // 起始日期变化
  @action.bound
  setStartTimeChange(date: any) {
    this.startTime = date === null ? '' : moment(date).format('YYYY-MM-DD');
  }
  // 结束日期变化
  @action.bound
  setEndTimeChange(date: any) {
    this.endTime = date === null ? '' : moment(date).format('YYYY-MM-DD');
  }
  // 点击排序,列表反转
  @action.bound
  listDataSortOfTime() {
    const temp = this.listData.slice();
    this.listData = temp.reverse();
  }
  // 合作社改变
  @action
  setCurCooperation(cooperate: any) {
    this.curCooperation = cooperate;
  }
  // 改变页数
  @action.bound
  changePage(page: number) {
    this.currentPage = page;
  }
  // 改变总条数
  @action
  changeTotal(totalSize: number) {
    this.itemCount = totalSize;
  }
  // 改变搜索内容
  @action
  changeSearch(value: string) {
    this.searchData = value;
  }
  // 重置数据
  @action
  clearData() {
    this.startTime = ''; // 起始时间
    this.endTime = ''; // 结束时间
    this.curOperator = ''; // 农机手
    this.listData = []; // 列表数据
    this.curCooperation = ''; // 合作社
    this.searchData = ''; // 搜索内容
    this.currentPage = 1; // 当前页数
    this.itemCount = 0; // 总条数
  }
  // 删除列表数据某项
  @action.bound
  deleteSingle(id: number) {
    const temp = this.listData.slice();
    this.listData = temp.filter(item => item.id !== id);
  }
}

export default new FarmListStore();
