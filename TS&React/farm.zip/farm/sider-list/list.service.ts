import { HttpClient } from '../../core/http-client';
import ListStore from './list.store';
import moment from 'moment';
import { message } from 'antd';
import DepartmentStore from '../../shared/departments/department.store';
// import LandPbStore from '../../shared/land/land.store';

interface ResponseData {
  data: { [x: string]: any };
  code: number;
}

export class ListService {
  // 获取列表便签
  static async getInquireAllListData(departmentID: number, query?: string, start?: string, end?: any) {
    try {
      const startData: string = (start === undefined || '') ? '' : `&start=${start}`;
      const endData: string = (end === undefined || '') ? '' : `&end=${end}`;
      const queryData: string = (query === undefined || '') ? '' : `&query=${query}`;
      // tslint:disable-next-line
      return HttpClient.get<ResponseData>(`/farmrecord/all?page=${ListStore.currentPage}&size=12&department=${departmentID}${startData}${endData}${queryData}&type=web`)
        .then((data: any) => {
          ListStore.setListData(data.farmrecords);
          ListStore.changeTotal(data.totalSize);
          // LandPbStore.setFilter(data.farmrecords);
          return data.farmrecords;
        });
    } catch (err) {
      throw err;
    }
  }

  // 点击查询
  static async clickTimeFind() {
    try {
      const { startTime, endTime, searchData } = ListStore;
      if ((startTime !== '') && (endTime !== '') && (moment(startTime).unix() - moment(endTime).unix() > 0)) {
        message.warning('起始时间应小于结束时间');
        return;
      }
      ListService.getInquireAllListData(DepartmentStore.curCooperation.departmentId, searchData, startTime, endTime);
    } catch (err) {
      throw err;
    }
  }

  // 搜索
  static async clickSearch(value: string) {
    try {
      ListStore.changeSearch(value);
      ListService.clickTimeFind();
      ListStore.changePage(1);
    } catch (err) {
      throw err;
    }
  }
}
