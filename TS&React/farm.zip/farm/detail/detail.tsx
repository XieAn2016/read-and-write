// Copyright 2018 sunhaonan (sunhaonan@gagogroup.com). All rights reserved.
// Use of this source code is governed a license that can be found in the LICENSE file.

/**
 * @component FarmInquireModelComp
 * @description 农事查询对话框
 * @time 2018/08/10
 * @author SHN
 */

import * as React from 'react';
import { Menu, Icon, Dropdown, message, Popconfirm, Input, Carousel } from 'antd';
import { ShadowScrollbars } from '../../shared';
import { TransWeek } from '../../../utils/transdate';
import moment from 'moment';
import { has } from 'lodash-es';
import Lightbox from 'react-images';
import { observer } from 'mobx-react';
// tslint:disable-next-line
const myAudio = require('../../../plugins/myaudio').default;
import { FarmService } from '../farm.service';
import { ListService } from '../sider-list/list.service';
import FarmStore from '../farm.store';
import FarmListStore from '../sider-list/list.store';
import DetailStore from './detail.store';
import { DetailService } from './detail.service';
import styles from './detail.module.scss';

const { TextArea } = Input;

@observer
export class DetailComponent extends React.Component<{}> {
  public slider = React.createRef<Carousel>();
  public leftArrow = React.createRef<HTMLDivElement>();
  public rightArrow = React.createRef<HTMLDivElement>();
  constructor(props?: any, context?: any) {
    super(props, context);
  }

  componentDidMount() {
    // Modal 异步的,取不到
    setTimeout(() => {
      const audio: HTMLElement | null = document.getElementById('modalaudio');
      audio && new myAudio(audio);
    }, 0);
  }

  // 修改卡片
  public editCard = () => {
    DetailStore.setEdit(true);
  }

  // 删除卡片
  public deleteCard = () => {
    FarmService.deleteCard(FarmStore.modalData.id)
      .then((result: any) => {
        if (result.code === 200) {
          FarmService.getNoteGeoJSON();
          message.success('删除成功');
        } else {
          message.error('删除失败');
        }
      });
  }

  // 删除图片
  public deleteImg = (value: number) => {
    FarmStore.deleteSingleImg(value);
  }

  // 点击取消
  public cancelEdit = () => {
    // 恢复图片为原始状态
    FarmStore.recoverImgs();
    // 取消编辑
    DetailStore.setEdit(false);
  }

  // 点击保存
  public saveCard = () => {
    // 保存(server)
    DetailService.saveDetail().then((data: any) => {
      if (data.code === 200) {
        message.success('修改成功');
        // 重新请求列表数据
        ListService.getInquireAllListData(1, FarmListStore.startTime, FarmListStore.endTime, FarmListStore.searchData);
      } else {
        message.error('修改失败');
      }
    });
    // 取消编辑
    DetailStore.setEdit(false);
  }

  // textArea
  public changeTextContent = (e: any) => {
    DetailStore.setTextArea(e.target.value);
  }

  // 点击图片进去轮播
  public clickImg = (imgNum: number) => {
    DetailStore.setShowCarousel(true);
    DetailStore.setCurImgNum(imgNum);
  }

  // 关闭 model
  public closeModel = () => {
    DetailStore.setShowCarousel(false);
    DetailStore.setCurImgNum(0);
  }

  // 点击左边的箭头
  public gotoPrevious = () => {
    DetailStore.setCurImgNum(DetailStore.curImgNum - 1);
  }

  // 点击右边的箭头
  public gotoNext = () => {
    DetailStore.setCurImgNum(DetailStore.curImgNum + 1);
  }

  // 点击预览
  public gotoImage = (index: number) => {
    DetailStore.setCurImgNum(index);
  }

  // 缩略图点击
  public handleClickImage = () => {
    if (DetailStore.curImgNum === FarmStore.modalData.recordPictureUrls.length - 1) return;
    this.gotoNext();
  }

  render() {
    const modalImgNum: number = has(FarmStore.modalData, 'recordPictureUrls') ? FarmStore.modalData.recordPictureUrls.length : 0;
    const mapObj: any = has(FarmStore.modalData, 'recordPictureUrls') ?
    FarmStore.modalData.recordPictureUrls.map((item: any) => { return { src: item }; }) : [];
    const menu = (
      <Menu>
        <Menu.Item>
          <div>
            <Icon type="edit" style={{ color: '#7b8587' }} onClick={this.editCard}/>
          </div>
        </Menu.Item>
        <Menu.Item>
          <div>
            <Popconfirm title="确定删除地块？" onConfirm={this.deleteCard} okText="确定" cancelText="取消">
              <Icon type="delete" style={{ color: '#7b8587' }}/>
            </Popconfirm>
          </div>
        </Menu.Item>
      </Menu>
    );
    return (
      <div>
        <div
          className={styles.inquireDetailCase}
        >
          <div className={styles.inquireModalHeader}>
            {DetailStore.isEdit ?
              <div>
                <span className={styles.detailCancel} onClick={this.cancelEdit}>取消</span>
                <span className={styles.detailOk} onClick={this.saveCard}>保存</span>
              </div> :
              <div>
                <i className={styles.seprate}/>
                <span className={styles.inquireRecord}>农事记录</span>
                <Icon type="close" style={{ float: 'right', cursor: 'pointer' }} onClick={FarmStore.handleCancelModal} />
              </div>
            }
          </div>
          <div className={styles.inquireModalDetail}>
          {
            has(FarmStore.modalData, 'updatedAt') ?
          <ShadowScrollbars style={{ height: `${modalImgNum > 0 ? '380px' : '150px'}` }}>
            <div className={styles.inquireModalBodyDetail}>
              <div className={styles.inquireCardContentBoxHeader}>
              <span className={styles.inquireCardCommonDate}>{moment(FarmStore.modalData.updatedAt).format('YYYY年MM月DD日')}</span>
              <span className={styles.inquireCardCommonWeek}>
                {TransWeek[moment(FarmStore.modalData.updatedAt).format('E') as any as number]}
              </span>
              <span className={styles.inquireCardCommonTitle}>{moment(FarmStore.modalData.updatedAt).format('HH:mm')}</span>
              <span className={`${styles.inquireCardCommonTitle} ${styles.inquireCardUserName}`}>{FarmStore.modalData.userName}</span>
              {
                !DetailStore.isEdit ?
                <div className={styles.fr}>
                <Dropdown overlay={menu}>
                  <i className={`${styles.inuqireModalMoreIcon} ant-dropdown-link`} />
                </Dropdown>
              </div> : null
              }
              </div>
              <div className={styles.mt10}>
                <i className={styles.inuqireModalLocationIcon} />
                <span
                  className={styles.inquireModalLocation}
                >
                  {FarmStore.modalData.recordLatitude.toFixed(2)} {FarmStore.modalData.recordLongitude.toFixed(2)}
                </span>
              </div>
            <div className={styles.inquireDetailContent}>
              {
                DetailStore.isEdit ?
                <TextArea
                  onChange={this.changeTextContent}
                  placeholder="请输入"
                  defaultValue={FarmStore.modalData.recordText}
                  autosize={{ minRows: 2 }}
                /> :
                <span>{FarmStore.modalData.recordText}</span>
              }
            </div>
            </div>
            {
              <div className={`${styles.inquireModalAudio} ${FarmStore.modalData.recordAudioUrl !== '' ? '' : styles.displayNone}`}>
                <audio src={FarmStore.modalData.recordAudioUrl} id="modalaudio" />
              </div>}
            <div>
            {
              modalImgNum > 0 && FarmStore.modalData.recordPictureUrls.map((item: any, index: number) => {
                return(
                  <div className={styles.inquireImgBox} key={`img${index}`}>
                    {DetailStore.isEdit ?
                    <div className={styles.inquireImgClose}>
                      <Popconfirm title="确定删除地块？" onConfirm={() => this.deleteImg(index)} okText="确定" cancelText="取消">
                        <Icon type="close" style={{ color: '#fff', cursor: 'pointer' }} />
                      </Popconfirm>
                    </div>
                    : null}
                    <img
                      src={item}
                      alt="田地图片"
                      className={styles.inquireDetailImg}
                      key={`farmInquireImg${index}`}
                      onClick={this.clickImg.bind(this, index)}
                    />
                  </div>
                );
              })
            }
            </div>
            </ShadowScrollbars>
            : null}
            {
              modalImgNum > 0 ?
              <Lightbox
                currentImage={DetailStore.curImgNum}
                images={mapObj}
                isOpen={DetailStore.isShowCarousel}
                onClickNext={this.gotoNext}
                onClickPrev={this.gotoPrevious}
                onClose={this.closeModel}
                onClickImage={this.handleClickImage}
                onClickThumbnail={this.gotoImage}
                imageCountSeparator={'/'}
                showThumbnails
              /> : null
            }
          </div>
        </div>
      </div>
    );
  }
}
