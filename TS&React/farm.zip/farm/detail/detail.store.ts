import { observable, action } from 'mobx';

export class DetailStore {
  @observable isEdit = false; // 是否为编辑
  @observable textArea = ''; // 文本框内容
  @observable isShowCarousel = false; // 是否显示轮播
  @observable curImgNum = 0; // 当前第几张图片

  // 更改编辑状态
  @action.bound
  setEdit(data: boolean) {
    this.isEdit = data;
  }

  // 更改备注内容
  @action
  setTextArea(value: string) {
    this.textArea = value;
  }

  // 更改轮播显隐
  @action
  setShowCarousel(value: boolean) {
    this.isShowCarousel = value;
  }

  // 当前图片数
  @action
  setCurImgNum(value: number) {
    this.curImgNum = value;
  }
}

export default new DetailStore();
