import { HttpClient } from '../../core/http-client';
import FarmStore from '../../farm/farm.store';
import DetailStore from './detail.store';

interface SaveResponse {
  code: number;
}

export class DetailService {
  // 保存修改农田记录
  static async saveDetail() {
    try {
      const { id, recordLongitude, recordLatitude, recordPictureUrls, recordAudioUrl } = FarmStore.modalData;
      const params: {[x: string]: any} = {
        recordLongitude,
        recordLatitude,
        recordText: DetailStore.textArea,
        existedPic: recordPictureUrls,
        existedAudio: recordAudioUrl,
      };
      return HttpClient.post<SaveResponse>(`/farmrecords/${id}`, params)
        .then((result: any) => {
          FarmStore.changeRemark(DetailStore.textArea);
          return {
            code: result.code,
          };
        });
    } catch (err) {
      throw err;
    }
  }
}
