/*
Copyright 2018 sunhaonan (sunhaonan@gagogroup.com). All rights reserved.
Use of this source code is governed a license that can be found in the LICENSE file.
*/

/**
 * @component FarmInquirePage
 * @description 农事查询页面
 * @time 2018/08/09
 * @author SHN
 */

import * as React from 'react';
import { observer } from 'mobx-react';
import { SiderListComponent } from './sider-list/sider-list';
import { DetailComponent } from './detail/detail';
import FarmStore from './farm.store';
import { FarmService } from './farm.service';
import { MapComponent } from './map/map';
// tslint:disable-next-line
const myAudio = require('../../plugins/myaudio').default;

@observer
export class FarmInquirePage extends React.Component {

  componentDidMount() {
    // 初始化 audio
    const audios: any[] = Array.from(document.getElementsByClassName('myaudio'));
    audios.forEach(ele => {
      new myAudio(ele);
    });
  }

  componentWillUnmount() {
    FarmStore.clearData();
  }

  render() {
    return (
      <>
        <MapComponent />
        <div>
          {FarmStore.modalVisible ? <DetailComponent /> : null}
          <SiderListComponent
            curCardChange={FarmService.getNoteDetail}
            highlightCardID={FarmStore.highlightCardID}
          />
        </div>
      </>
    );
  }
}
