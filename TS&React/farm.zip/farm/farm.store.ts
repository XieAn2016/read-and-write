import { observable, action } from 'mobx';

interface MapConfig {
  center: number[] | undefined;
  noteFilter: any[];
  highlightNoteFilter: any[];
}

export class FarmStore {
  @observable map: MapConfig = {
    center: undefined,
    noteFilter: ['has', 'id'],
    highlightNoteFilter: ['==', 'id', ''],
  };
  @observable modalVisible = false; // 对话框
  @observable.ref modalData: { [x: string]: any } = {}; //  对话框数据
  @observable highlightCardID = -1; // 高亮卡片 id
  @observable initImgs: string[] = []; // 初始请求来的图片
  @observable.ref geojsonNote = ''; // note symbolLayer geojson

  // 打开 model
  @action.bound
  handleOKModal() {
    this.modalVisible = true;
  }
  // 关闭 model
  @action.bound
  handleCancelModal() {
    this.modalVisible = false;
    this.highlightCardID = -1;
    this.updateFilter(['has', 'id'], ['==', 'id', '']);
  }
  // 获取便签详情
  @action
  setNoteDetail(data: {[x: string]: any}, id: number) {
    this.highlightCardID = id;
    this.updateFilter(['!=', 'id', id], ['==', 'id', id]);
    this.modalData = data;
    this.initImgs = data.recordPictureUrls;
    this.handleOKModal();
  }

  // jumpTo
  @action
  setCenter(lng: number, lat: number) {
    this.map.center = [lng, lat];
  }

  // 改变筛选
  @action
  updateFilter(noteFilter: any[], highlightNoteFilter: any[]) {
    this.map.noteFilter = noteFilter;
    this.map.highlightNoteFilter = highlightNoteFilter;
  }

  // 删除 modelData 单张图片
  @action
  deleteSingleImg(value: number) {
    const temp = Object.assign({}, this.modalData);
    temp.recordPictureUrls.splice(value, 1);
    this.modalData = temp;
  }

  // 恢复图片为原始状态
  @action
  recoverImgs() {
    this.modalData.recordPictureUrls = this.initImgs;
  }

  // 修改备注
  @action.bound
  changeRemark(data: string) {
    this.modalData = { ...this.modalData, recordText: data };
  }

  // note geojson
  @action
  setGeojson(value: any) {
    this.geojsonNote = value;
  }

  // clearData
  @action
  clearData() {
    this.map = {
      center: undefined,
      noteFilter: ['has', 'id'],
      highlightNoteFilter: ['==', 'id', ''],
    };
    this.modalData = {};
    this.modalVisible = false;
    this.highlightCardID = -1;
  }
}

export default new FarmStore();
