import React, { Component } from 'react';
import { when } from 'mobx';
import { observer } from 'mobx-react';

import {
  MapStore,
  Mapbox,
  BaseLayer,
  Control,
  BoundaryLine,
  Annotation,
  Source,
  Layer,
  Image,
  GeoJSONSourceOptions,
  SymbolLayerOptions,
} from '../../shared/mapbox';
import { LayerControl } from '../../shared/label-control/label-control';
import FarmStore from '../farm.store';
import { FarmService } from '../farm.service';
import LabelStore from '../../shared/label-control/label-control.store';
import { CommonLand } from '../../shared/land/land';

import notePath from './note.png';
import highlightNotePath from './highlight-note.png';

@observer
export class MapComponent extends Component {

  public mapOnLoad = () => {
    (async () => {
      await when(() => MapStore.map !== null && MapStore.images.has('note') && MapStore.images.has('highlight-note'));
      await FarmService.getNoteGeoJSON();
    })();
  }

  handleNoteClick = (e: any) => {
    const id = e.features[0].properties.id;
    FarmService.getNoteDetail(id);
    FarmStore.updateFilter(['!=', 'id', id], ['==', 'id', id]);
  }

  render() {
    const noteLayerOptions: SymbolLayerOptions = {
      id: 'farm-note',
      type: 'symbol',
      source: 'farm-note',
      layout: {
        'icon-image': 'note',
        'icon-allow-overlap': true,
      },
      filter: FarmStore.map.noteFilter,
    };

    const highlightNoteLayerOptions: SymbolLayerOptions = {
      id: 'farm-highlight-note',
      type: 'symbol',
      source: 'farm-note',
      layout: {
        'icon-image': 'highlight-note',
        'icon-allow-overlap': true,
      },
      filter: FarmStore.map.highlightNoteFilter,
    };

    const jumpTo = FarmStore.map.center === undefined ? undefined : {
      options: {
        center: FarmStore.map.center.slice(),
      },
    };

    return (
      <Mapbox options={{ center: [120.7, 37.16], zoom: 14 }} jumpTo={jumpTo} onLoad={this.mapOnLoad} >
        <BaseLayer type="google-satellite" visibility={LabelStore.baseLayers.get('google-satellite')} />
        <BaseLayer type="google-normal" visibility={LabelStore.baseLayers.get('google-normal')} />
        <BoundaryLine />
        <Annotation />
        <Image name="note" url={notePath} />
        <Image name="highlight-note" url={highlightNotePath} />
        <CommonLand />

        <Source<GeoJSONSourceOptions> id="farm-note" reload options={{ type: 'geojson', data: FarmStore.geojsonNote }} />
        <Layer<SymbolLayerOptions> options={noteLayerOptions} onClick={this.handleNoteClick} />
        <Layer<SymbolLayerOptions> options={highlightNoteLayerOptions} />

        <Control type="scale" position="bottom-right" options={{ maxWidth: 80, unit: 'metric' }} />
        <Control type="navigation" position="bottom-right" options={{ showCompass: false }} />
        <LayerControl />
      </Mapbox>
    );
  }
}
