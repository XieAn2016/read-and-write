import { HttpClient } from '../core/http-client';
import FarmStore from './farm.store';
import ListStore from './sider-list/list.store';

interface ResponseData {
  [x: string]: any;
}

interface DelResponseData {
  id: number;
  code: number;
}

export class FarmService {
  // 获取便签详情
  static async getNoteDetail(id: number, lng?: number, lat?: number) {
    if (typeof lng === 'number' && typeof lat === 'number') {
      FarmStore.setCenter(lng, lat);
    }

    return HttpClient.get<ResponseData>(`/farmrecord/${id}`)
      .then((data) => {
        FarmStore.setNoteDetail(data.farmrecord, id);
      });
  }

  // 获取 note 点位
  static async getNoteGeoJSON() {
    try {
      return HttpClient.get('/farmrecord/geojson')
        .then(data => {
          FarmStore.setGeojson(data.geojson);
        });
    } catch (err) {
      throw err;
    }
  }

  // 删除 card
  static async deleteCard(id: number) {
    try {
      return HttpClient.delete<DelResponseData>(`/farmrecords/${id}`)
        .then((result) => {
          // 关闭详情框
          FarmStore.handleCancelModal();
          // 删除列表数据
          ListStore.deleteSingle(id);
          // 删除地图数据 todo
          return {
            id: result.id,
            code: result.code,
          };
        });
    } catch (err) {
      throw err;
    }
  }
}
